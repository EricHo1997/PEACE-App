//
//  SignUpPageViewController.swift
//  SIT206-Assingment2-PEACEAPP
//
//  Created by TAMMY LE on 9/5/18.
//  Copyright © 2018 NGOC THE HO. All rights reserved.
//

import UIKit

class SignUpPageViewController: UIViewController {

    @IBOutlet weak var userEmailTextField: UITextField!
    @IBOutlet weak var userPasswordTextField: UITextField!
    @IBOutlet weak var retypePasswordTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func JoinButtonTapped(_ sender: Any) {
        
        let userEmail = userEmailTextField.text;
        let userPassword = userPasswordTextField.text;
        let userRetypePassword = retypePasswordTextField.text;
        
        // check empty fields
        if(userEmail!.isEmpty || userPassword!.isEmpty || userRetypePassword!.isEmpty )
        {
            //display alert message
            displayAlertMessage(userMessage: "Fields are required");
            return;
        }
        
        //check if passwords match
        if(userPassword != userRetypePassword)
        {
            //display an alert message
            displayAlertMessage(userMessage: "Passwords do not match");
            return;
        }
        //store data
        
        UserDefaults.standard.set(userEmail, forKey: "userEmail");
        UserDefaults.standard.set(userPassword, forKey: "userPassword");
        UserDefaults.standard.synchronize();
        
        // display alert message with confirmation
        var myAlert = UIAlertController(title:"Alert", message: "Signed up successfully. Thank you!", preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default)
        {
            action in self.dismiss(animated: true, completion:nil);
        }
        
        myAlert.addAction(okAction);
        self.present(myAlert, animated: true, completion:nil);
        
        
    }
    
    func displayAlertMessage(userMessage:String)
    {
        var myAlert = UIAlertController(title:"Alert", message: userMessage, preferredStyle: UIAlertControllerStyle.alert)
        
        let okAction = UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler:nil);
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated: true, completion:nil);
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
