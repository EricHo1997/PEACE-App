//
//  ScenesTableViewController.swift
//  SIT206-Assingment2-PEACEAPP
//
//  Created by NGOC THE HO on 16/5/18.
//  Copyright © 2018 NGOC THE HO. All rights reserved.
//

import UIKit
import AVFoundation

class ScenesTableViewController: UITableViewController{

    @IBOutlet weak var M_Scenes: UITableView!
    
    var player = AVAudioPlayer()
    
    // Songs are played when you touch on the row
    func playSong(index: Int){
        do{
            let songPath = Bundle.main.path(forResource: songs[index], ofType: ".mp3", inDirectory: "songs")
            try player = AVAudioPlayer(contentsOf: URL(fileURLWithPath: songPath!))
            player.play()
        }catch{}
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        playSong(index: indexPath.row)
    }
    
    // Make the songs to the array
    var songs: [String] = []
    
    func getSongs() -> [String] {
        var names: [String] = []
        let path = Bundle.main.resourceURL?.appendingPathComponent("songs")
        do{
            let songs = try FileManager.default.contentsOfDirectory(at: path!, includingPropertiesForKeys: nil, options: FileManager.DirectoryEnumerationOptions.skipsHiddenFiles)
            
            for song in songs{
                let strArray = song.absoluteString.components(separatedBy: "/")
                var songName = strArray[strArray.count-1].replacingOccurrences(of: "%20", with: " ")
                songName = songName.replacingOccurrences(of: ".mp3", with: "")
                names.append(songName)
            }
        } catch{}
        
        return names
    }
    
    // this func so the songs in ScenesUITableView
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.songs.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:UITableViewCell = self.tableView.dequeueReusableCell(withIdentifier: "cell")!
        cell.textLabel?.text = self.songs[indexPath.row]
        return cell
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        songs = getSongs()
        
        self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        tableView.delegate = self
        tableView.dataSource = self
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source
    
    

    
    

    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

class PlayList {
    var songsBySinger : [String : [String]] = [ String : [String]] ()
    var songs : [String] = [String]()
    init() {
        songs += ["yanni_allsessons", "adele_hello", "luis fonsi_despacito"]
        songsBySinger = [
            "G1" : ["yanni_allsessons"] ,
            "G2" : ["adele_hello"],
            "G3" : ["Luis Fonsi_despacito"]
        ]
    }
    func getSongAt(forSinger : String, index : Int) -> (song : String, singer : String) {
        if forSinger == "All" {
            let song = songs[ abs(index) % songs.count ]
            let singer = String(song[..<song.index(of: "_")!])
            return ( song, singer)
        }
        if songsBySinger[forSinger] != nil {
            let song = songsBySinger[forSinger]![ abs(index) % songsBySinger[forSinger]!.count]
            return ( song, forSinger)
        }
        return ("" , "")
        
    }
    
}

